<?php

function hello($data)
{
    return "Hello, {$data['name']}!";
}
